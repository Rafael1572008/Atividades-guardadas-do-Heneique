//item
console.log("Script Carregado")

//item 2
function calcularAnos(){

//item 3
console.log("Botão de Calcular clicando")

//item 4
let popAInput = document.getElementById("popA").value.trim();

//item 5
let taxaAInput= document.getElementById("taxaA").value.trim();

//item 6
let popBInput = document.getElementById("popB").value.trim();

//item 7
let taxaBInput= document.getElementById("taxaB").value.trim();

//item 8
if(popAInput == "" || taxaAInput == "" || popBInput == "" || taxaBInput == ""){

//item 9
alert("Por favor, Preencha todos os campos");

//item 10
return;

//item 11
}

//item 12
let popA = parseInt(popAInput);

//item 13
let taxaA = parseFloat(taxaAInput)/100;

//item 14
let popB = parseInt(popBInput);

//item 15
let taxaB = parseFloat(taxaBInput)/100;

//item 16
let anos = 0;

//item 17
while (popA<popB){
    //item 18
    popA *= (1*taxaA);

    popB *= (1*taxaB);

    anos ++;

//item 19    
}

//item 20
console.log("Anos calculados: ", anos)

//item 21
let resultados = document.getElementById("resultados")

resultados.innerHTML = `Seraão necessarios ${anos} para que a população do pais A ultrapasse ou iguale a população B`;

//item 22
}

//item 23
function limparCampos(){
    //item 24
    console.log("Botão de limpar campus");
    //item 25
    document.getElementById("popA").value = "";
    //item 26
    document.getElementById("taxaA").value = "";
    //item 27
    document.getElementById("popB").value = "";
    //item 28
    document.getElementById("taxaB"). value = "";
    //item 29
    let resultado = document.getElementById("resultados")

    //item 30
    resultado.innerHTML = "";
}
from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        desenvolvedor = request.form['desenvolvedor']
        turma = request.form['turma']
        professor = request.form['professor']
        data_desenvolvimento = request.form['data']
        dificuldade = request.form['dificuldade']
        confiante = request.form['confiante']
        return render_template('resultados.html', desenvolvedor=desenvolvedor, turma=turma, professor=professor,
                               data_desenvolvimento=data_desenvolvimento, dificuldade=dificuldade, confiante=confiante)
    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)